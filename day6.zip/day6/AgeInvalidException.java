package satya;

public class AgeInvalidException extends Exception {
	AgeInvalidException(String message){
		super(message);
	}

}
