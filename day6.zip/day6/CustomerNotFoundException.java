package satya;

public class CustomerNotFoundException extends Exception {
	CustomerNotFoundException(String message)
	{
		super(message);
	}
}
