package satya;

public class MinBalException extends Exception {
	MinBalException(String message)
	{
		super(message);
	}
}
