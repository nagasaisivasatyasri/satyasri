package satya;
import java.lang.*;
import java.util.InputMismatchException;
public class Account {
	String aType;
	int accNo;
	 String accHolder;
	 int age;
	 int bal;
	Customer q=new Customer();
	void addCustomer()
	{
	System.out.println("Enter Account type");
	 aType=Bank.s.next();
	Bank.s.nextLine();
	System.out.println("Enter customer account Number ");
	try {
	 accNo=Bank.s.nextInt();
	}
	catch(InputMismatchException e)
	{
		System.out.println(e);
	}
	finally
	{
		System.out.println("end");
	}
	System.out.println("Enter account holder");
	 accHolder=Bank.s.nextLine();
	Bank.s.nextLine();
	System.out.println("Enter branch  name:");
	String bname=Bank.s.next();
	Bank.s.nextLine();
	System.out.println("Enter age");
	age=Bank.s.nextInt();
	if(age<18) {
	try {
		throw new AgeInvalidException("Not eligible to create account");
	}
	catch(AgeInvalidException e)
	{
	e.printStackTrace();	
	}
	finally {
		System.out.println("end");
	}
	}
	System.out.println("Enter bank bal");
	bal=Bank.s.nextInt();
	if(bal<2000)
	{
		try
		{
			throw new MinBalException("Bal is less,maintain Minimum balance");
			
		}
		catch(MinBalException e) {
			e.printStackTrace();
		}
		finally
		{
			System.out.println("end");
		}
	}
	Customer.add(aType,accNo,accHolder,bname,age,bal);
}
	void deleteCustomer()
	{
		int x=Bank.s.nextInt();
		Customer.del(x);
	}
 void editCustomer()
	{
	 System.out.println("Enter acc Number to edit");
	 int d=Bank.s.nextInt();
		Customer.edit(d);
		
	}
 void selectCustomer()
 {
	 System.out.println("Enter accNumber");
	 int o=Bank.s.nextInt();
	 q.select(o);
 }
	public Account(String aType, int accNo, String accHolder) {
		this.aType = aType;
		this.accNo = accNo;
		this.accHolder = accHolder;
	}
	public Account() {}


}
