package com.question2;
 class Person {
	String name="sai";
	int age=23;
	int id=45;
	String city="Vijayawada";
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", id" + id + "]";
	}
	
	}


