package com.question2;
class Student extends Person {
	int sid=23;
	String sname="satya";
	String scityname="palasa";
	double avg=52.63d;
	@Override
	public String toString() {
		
	Person p=new Person();
	System.out.println(p);
		return "Student [sid=" + sid + ", sname=" + sname + ", scityname=" + scityname + ", avg=" + avg + "]";
	}
	 
	
}
