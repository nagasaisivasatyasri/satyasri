package com.question2;

//import com.src.person.Student;

public class MainClass  {
	public static void main(String []args) {
		Student s=new Student();
		System.out.println(s);
	}

}
