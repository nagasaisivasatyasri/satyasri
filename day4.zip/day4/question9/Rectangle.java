//package question9;

public class Rectangle extends Shape{
	private double length,width;
	@Override
	double area() {
		// TODO Auto-generated method stub
		return length*width;
	}
		public Rectangle(double length, double width) {
		//super();
		this.length = length;
		this.width = width;
	}
	@Override
	double perimeter() {
		// TODO Auto-generated method stub
		return 2*(length+width);
	}
	@Override
	public String toString() {
		super.toString();
		System.out.println();
		return "Rectangle [length=" + length + ", width=" + width + ", area()=" + area() + ", perimeter()="
				+ perimeter() + "]";
	}

}
