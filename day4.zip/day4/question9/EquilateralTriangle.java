//package question9;

public class EquilateralTriangle extends Shape{
	private double side;
	@Override
	double area() {
		// TODO Auto-generated method stub
		return (Math.sqrt(3)*side*side)/4;
	}

	public EquilateralTriangle(double side,double side1,double side2) {
		//super();
		this.side = side1;
		this.side=side2;
		//this.side=side3;
	}

	@Override
	double perimeter() {
		// TODO Auto-generated method stub
		return 3*side;
	}

	@Override
	public String toString() {
		super.toString();
		System.out.println();
		return "Triangle [side=" + side + ", area()=" + area() + ", perimeter()=" + perimeter() + "]";
	}

}
