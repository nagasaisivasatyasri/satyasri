//package question9;

import java.util.Arrays;

public class RectangleSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Shape vec[] = new Shape[50];
          for(int index=0; index<vec.length; index++)
          {
                    switch((int)(4*Math.random()))
                    {
                             case 1:
                                                 vec[index] = new Rectangle(1000*Math.random(), 1000*Math.random());
                                                 break;
                             case 2:
                                                 vec[index] = new Circle(1000*Math.random());
                                                 break;
                             default:
                                                 vec[index] = new EquilateralTriangle(1000*Math.random(), 1000*Math.random(), 1000*Math.random());
                    }
          }

          Arrays.sort(vec);

          for(int index=0; index<vec.length; index++)
          {
                    System.out.println(vec[index]);
          }

	}

}
