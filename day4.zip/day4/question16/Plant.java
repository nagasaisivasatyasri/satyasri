package com.question16;

public class Plant {
	String name="Tulasi";
	 
	
	public void grow()
	{
		System.out.println(name+"Plant is growing");
	}

}
