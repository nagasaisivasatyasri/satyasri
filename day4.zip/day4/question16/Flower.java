package com.question16;

public class Flower extends Plant {
	 	String name="rose";
		
		public Flower() {
			super();
			//this.name = name;
		}

		public void grow()
		{
			super.grow();
			System.out.println(name+" flower is beautiful");
		}
		 
	 }


