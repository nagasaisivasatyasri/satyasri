package com.question16;

class Tree extends Plant {
	String name="mango";

	public Tree() {
		super();
		//this.name = name;
	}

	public void grow() {
		super.grow();
		System.out.println(name+"Tree is growing");
	}
}
  