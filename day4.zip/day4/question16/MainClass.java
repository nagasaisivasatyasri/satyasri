package com.question16;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tree t=new Tree();
		 t.grow();
		 Flower f=new Flower();
		// t=new Flower("Rose");
		 f.grow();

	}

}
