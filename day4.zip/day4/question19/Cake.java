package com.question19;

//public class Cake {
	class Cake extends Bread{
		public void bakingCake()
		{
			super.bakingBread();
			System.out.println("baking cake");
		}

	}


