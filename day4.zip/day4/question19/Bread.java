package com.question19;

public class Bread {
public void bakingBread()
{
	System.out.println("baking Bread");
}
}
