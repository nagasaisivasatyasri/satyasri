package com.question19;

//public class MainClass {
	class MainClass
	{
		public static void main(String []args)
		{
			Cake c=new Cake();
			c.bakingCake();
		}
	}

