package com.question7;

import java.util.Arrays;

public class RectangleSort {
public static void main(String []args) {
	Rectangle vec[];
    vec = new Rectangle[50];
    double randomWidth=0, randomHeight=0;
    for(int index=0; index<vec.length; index++)
    {
    	
            randomWidth = 10* Math.random();
              //System.out.println(randomWidth);
              randomHeight =10*  Math.random();
             // System.out.println(randomHeight);
              vec[index] = new Rectangle(randomWidth, randomHeight);
    }

   Arrays.sort(vec);
   
    for(int index=0; index<vec.length; index++)
    {
              System.out.println(vec[index]);
    }

}
}
