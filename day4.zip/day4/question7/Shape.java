package com.question7;

public abstract class Shape {
	abstract double area();
    public String toString()
    {
             return "area="+area();
    }

}
