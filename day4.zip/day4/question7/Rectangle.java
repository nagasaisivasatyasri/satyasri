package com.question7;
import java.lang.Comparable;
public class Rectangle extends Shape implements Comparable{
	double l,b;

	public Rectangle(double l, double b) {
	this.l = l;
	this.b = b;
}

	@Override
	double area() {
		// TODO Auto-generated method stub
		return l*b;
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		//double d=(double)o;
		//if()
		Rectangle r=(Rectangle)o;
		if(this.area()>r.area())
		{
			return 1;
		}
		else {
		return -1;}
	}

	


}
