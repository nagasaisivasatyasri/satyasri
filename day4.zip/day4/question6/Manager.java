package com.question6;

public class Manager implements Printable{
String name;
int id;

	public Manager(String name, int id) {
	this.name = name;
	this.id = id;
}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("name "+name+" id "+id);
	}

}
