package com.question6;

public interface Printable {
public void print();
}
