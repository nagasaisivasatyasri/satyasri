package com.question6;

public class SportsCar implements Printable{
String name;
int model;

	public SportsCar(String name, int model) {
	this.name = name;
	this.model = model;
}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Car name "+name+" model name "+model);
	}

}
