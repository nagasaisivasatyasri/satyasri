package com.question6;

public class Rectangle implements Printable{
int l,b;

	public Rectangle(int l, int b) {
	this.l = l;
	this.b = b;
}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("area is "+l*b);
	}
	

}
