package com.question6;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	    Printable vec[] = {new Rectangle(200,100), new SportsCar("Fiat", 7892321),
                new Rectangle(34,32), new Manager("Gidi", 32),
                new Rectangle(54,10), new SportsCar("Audi", 4322344),
                new SportsCar("Mazda", 4322343), new Manager("Moshe", 2344322)};
for(int index=0; index<vec.length; index++)
{
vec[index].print();
}

	}

}
