package com.question4;
class Circle extends Shape {
int r;
public double area()
{
	return 3.14*r*r;
}
public Circle(int r) {
	this.r = r;
}

}
