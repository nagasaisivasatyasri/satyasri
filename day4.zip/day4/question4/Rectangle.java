package com.question4;
public class Rectangle extends Shape 
{
int l,b;
public double area()
{
	return l*b;
}
public Rectangle(int l, int b) {
	this.l = l;
	this.b = b;
}

/*public Rectangle(double l2, double b2) {
	// TODO Auto-generated constructor stub
}*/

}
