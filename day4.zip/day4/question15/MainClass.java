package com.question15;

public class MainClass {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JavaArchitect a=new JavaArchitect();
a.architect();
	}

}
