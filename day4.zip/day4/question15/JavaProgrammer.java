package com.question15;

 class JavaProgrammer {
	 int number1=10,number2=20;
	public void programmer()
	{
		System.out.println(number1+" "+number2);
		System.out.println("Programming is done");
	}
	public void add()
	{
		System.out.println("adding"+(number1+number2));
	}
}
 
// class JavaArchitect 		
//}
 

