package com.question15;

public class JavaDeveloper extends JavaProgrammer {
	int number1=40,number2=50;
	public void developer()
	{
		super.programmer();
		System.out.println(number1+" "+number2);
		System.out.println("development is done");
	}
	public void sub()
	{
		super.add();
		System.out.println("subtracting"+(number1-number2));
	}

}
