package com.question15;

public class JavaArchitect extends JavaDeveloper{
	 int a=35,b=56;
		public void architect() {
		super.developer();
		
		System.out.println(a+" "+b);
		System.out.println("designing is done");
		mul();
	}
		public void mul()
		{
			super.sub();
			System.out.println(a*b);
		}
 

}
