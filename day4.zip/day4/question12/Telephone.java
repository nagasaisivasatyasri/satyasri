package com.question12;

import java.awt.Color;

public class Telephone extends Appliance{
	private double voltage;
	private String madein;
	private double price;
	private java.awt.Color color;
	public Telephone(double voltage, Color color, String madein, double price) {
		super(voltage, color, madein, price);
		this.voltage = voltage;
		this.color=color;
		this.madein = madein;
		this.price = price;
	}
	

	public double getVoltage() {
		return voltage;
	}
	public void setVoltage(double voltage) {
		this.voltage = voltage;
	}
	public String getMadein() {
		return madein;
	}
	public void setMadein(String madein) {
		this.madein = madein;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}


	@Override
	public String toString() {
		System.out.println(super.toString());

		return "Telephone [voltage=" + voltage + ", madein=" + madein + ", price=" + price + ", color=" + color + "]";
	}
	
	}
