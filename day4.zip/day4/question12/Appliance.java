package com.question12;
import java.lang.Comparable;
import java.awt.Color;
import java.awt.Color.*;
public class Appliance implements Comparable {

	private double voltage;
	public java.awt.Color color;
	private String madein;
	private double price;
	
	
	public Appliance() {
	//	super();
	}


	public Appliance(double voltage, Color color, String madein, double price) {
		//super();
		this.voltage = voltage;
		this.color = color;
		this.madein = madein;
		this.price = price;
	}


	public double getVoltage() {
		return voltage;
	}


	public void setVoltage(double voltage) {
		this.voltage = voltage;
	}


	public java.awt.Color getColor() {
		return color;
	}


	public void setColor(java.awt.Color color) {
		this.color = color;
	}


	public String getMadein() {
		return madein;
	}


	public void setMadein(String madein) {
		this.madein = madein;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "Appliance [voltage=" + voltage + ", color=" + color + ", madein=" + madein + ", price=" + price + "]";
	}


	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		Appliance a=(Appliance)o;
		if(this.price>a.price) {
			return 1;
		}
		else if(this.price<a.price) {
			return -1;
		}
		else {
		return 0;}
	}

}
