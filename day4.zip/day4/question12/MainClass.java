package com.question12;

import java.awt.Color;
import java.util.Arrays;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Appliance vec[]=new Appliance[40];
for(int index=0;index<vec.length;index++)
{
	switch((int)(4*Math.random()))
	{
	case 1:
		vec[index] = new Toaster(10000 * Math.random(),Color.black, "japan",10000*Math.random());
		break;
	case 2:
		vec[index] = new TV(10000*Math.random(),Color.RED, "Germany",10000*Math.random());
		break;
	default:
		vec[index] = new Telephone(10000*Math.random(),Color.BLUE, "India",10000*Math.random());
		break;
	}
}
Arrays.sort(vec);
for(int index=0;index<vec.length;index++) {
	System.out.println(vec[index]);
	System.out.println(" ");
}
	}

}
