package com.question20;

public class Car {
String name,model;

public Car(String name, String model) {
	this.name = name;
	this.model = model;
}
public void show()
{
	System.out.println(name+" "+model);
}
@Override
public String toString() {
	return "Car [name=" + name + ", model=" + model + "]";
}


}
