package com.question20;

//public class Bus {
	class Bus extends Car
	{
		String name,model;

		public Bus(String name, String model) {
			super("safari","dfe");
			this.name = name;
			this.model = model;
		}
		public void display()
		{
			super.show();
			System.out.println(name+" "+model);
		}
		@Override
		public String toString() {
			Car c=new Car("Maruthi","suzaki");
			System.out.println(c);
			return "Bus [name=" + name + ", model=" + model + "]";
		}
	}
	

