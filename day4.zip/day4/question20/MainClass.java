package com.question20;

public class MainClass {
	//class Cb
	//{
		public static void main(String []args)
		{
			Bus b=new Bus("Tata","Star Plus");
			b.display();
			System.out.println(b);
		}
		
	}


