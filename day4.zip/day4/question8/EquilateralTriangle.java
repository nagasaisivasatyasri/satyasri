//package question8;

public class EquilateralTriangle extends Shape {
private double side;
	@Override
	double area() {
		// TODO Auto-generated method stub
		return (Math.sqrt(3)*side*side)/4;
	}

	public EquilateralTriangle(double side) {
		//super();
		this.side = side;
	}

	@Override
	double perimeter() {
		// TODO Auto-generated method stub
		return 3*side;
	}

	@Override
	public String toString() {
		super.toString();
		System.out.println();
		return " Triangle [side=" + side + ", area()=" + area() + ", perimeter()=" + perimeter() + "]";
	}

}
