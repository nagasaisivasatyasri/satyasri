//package question8;

public class Circle extends Shape{
private double radius;
	@Override
	double area() {
		// TODO Auto-generated method stub
		return 3.14*radius*radius;
	}

	public Circle(double radius) {
		//super();
		this.radius = radius;
	}

	@Override
	double perimeter() {
		// TODO Auto-generated method stub
		return 2*3.14*radius;
	}

	@Override
	public String toString() {
		super.toString();
		System.out.println();
		return " Cicle [radius=" + radius + ", area()=" + area() + ", perimeter()=" + perimeter() + "]";
	}
	

}
