//package question8;
import java.lang.Comparable;
public abstract class Shape implements Comparable {
	abstract double area();
    abstract double perimeter();
    public int compareTo(Object other)
    {
    	Shape s=(Shape)other;
    	if(this.area()>s.area())
    	{
    		return 1;
    	}
    	else if(this.area()<s.area())
    	{
    		return -1;
    		    	}
    	else {
		return 0;}
             //add the missing code
                }

    public String toString()
    {
             return "area="+area();
    }

}
