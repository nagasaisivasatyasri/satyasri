package com.question3;

public class SportCar extends Car {
private String name="abarth";
private String model="124 spider";
private int cost=420000000;
public void accelerate() {
	super.accelerate();
	System.out.println("Accelerating sportscar and can go with superspeed");
}
public void breakSportCar() {
	super.breakCar();
	System.out.println("Apply break smoothly");
}
@Override
public String toString() {
	Car c=new Car();
	System.out.println(c);
	return "SportCar [name=" + name + ", model=" + model + ", cost=" + cost + "]";
}
public SportCar() {
	}

}
