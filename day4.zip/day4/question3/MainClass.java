package com.question3;

public class MainClass {
public static  void main(String []args) {
	SportCar s1=new SportCar();
	s1.accelerate();
	s1.breakSportCar();
	
	System.out.println(s1);
	//System.out.println(c);
	
}
}
