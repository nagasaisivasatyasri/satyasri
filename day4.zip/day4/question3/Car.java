package com.question3;

public class Car {
	private String name="tata";
	private String model="altroz";
	private int cost=700000;
	public void accelerate() {
		System.out.println("Accelerating car and can go with normal speed");
	}
	public void breakCar() {
		System.out.println("Apply break normally");
	}
	@Override
	public String toString() {
		return "Car [name=" + name + ", model=" + model + ", cost=" + cost + "]";
	}
/*	public Car(String name, String model, int cost) {
		//super();
		this.name = name;
		this.model = model;
		this.cost = cost;
	}*/
	public Car() {
		//super();
	}

}
