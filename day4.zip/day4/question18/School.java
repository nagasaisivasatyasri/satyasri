package com.question18;

//public class School {
	class School extends University
	{
		String name;
		String city;
		public School(String name, String city) {
			super("Aims","Hyd");
			this.name = name;
			this.city = city;
		}
		public void display()
		{
			super.display();
			System.out.println(name+" "+city);
		}
		@Override
		public String toString() {
			University u=new University("Andhra University","Vizag");
			System.out.println(u);
			return "School [name=" + name + ", city=" + city + "]";
		}
		
		
	}


