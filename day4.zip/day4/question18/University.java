package com.question18;

public class University {

	String name;
	String city;
	
	public University(String name, String city) {
		this.name = name;
		this.city = city;
	}
	
	public University() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "University [name=" + name + ", city=" + city + "]";
	}

	public void display()
	{
		System.out.println(name+" "+city);
	}
	
}
 