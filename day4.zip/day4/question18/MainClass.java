package com.question18;

public class MainClass {
		public static void main(String []args)
		{
			School s=new School("Chaitanya","Vizag");
			s.display();
			System.out.println(s);
		}
	}


