package com.Question1;
import java.util.Scanner;

import java.lang.Math;
class GreatPointgp extends MyPoint{
	double point1;
	double point2;
public double distance()
{
	double c=Math.sqrt(point1*point1+point2*point2);
	return c;
}
public GreatPointgp(double point1, double point2) {
	super(point1,point2);
	this.point1=point1;
	this.point2=point2;
	
}
public GreatPointgp() {
	
}



}
