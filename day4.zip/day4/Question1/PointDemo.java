package com.Question1;

import java.util.Scanner;

public class PointDemo {

	public static void main(String []args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		double point1=sc.nextDouble();
		double point2=sc.nextDouble();
        GreatPointgp  gp=new GreatPointgp(point1,point2);
        System.out.println("The distance of gp from (0,0) is " + gp.distance());
        sc.close();
	}

}
