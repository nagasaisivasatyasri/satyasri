package com.Question1;

 class MyPoint {
	 private double x;
     private double y;
     MyPoint()
     {
     }
     MyPoint(double a, double b)
     {
              x=a;
              y=b;
     }
     public double getX()
     {
              return x;
     }
     public double getY()
     {
              return y;
     }
     public void setX(double xVal)
     {
              x = xVal;
     }
     public void setY(double yVal)
     {
              y = yVal;
     }

}
