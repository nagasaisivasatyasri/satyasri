package com.question13;

public class PizzaDelux extends Pizza{

	private double price;
	private String name;
	private double calories;

	public PizzaDelux(double price, String name, double calories) {
		super(price, name, calories);
		this.price=price;
		this.name=name;
		this.calories=calories;
		// TODO Auto-generated constructor stub
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getCalories() {
		return calories;
	}

	public void setCalories(double calories) {
		this.calories = calories;
	}

	@Override
	public String toString() {
		System.out.println(super.toString());
		return "PizzaDelux [price=" + price + ", name=" + name + ", calories=" + calories + "]";
	}
	

}
