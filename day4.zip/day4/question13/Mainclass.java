package com.question13;

import java.util.Arrays;

public class Mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Pizza p[]=new Pizza[40];
for(int index=0;index<p.length;index++) 
{
	switch ((int) (4 * Math.random()))
	{
	case 1:
		p[index] = new PizzaDelux(1000 * Math.random(), "Pizzadelux", 1000 * Math.random());
		break;
	case 2:
		p[index] = new PizzaSpecial(1000 * Math.random(), "PizzaSpecial", 1000 * Math.random());
		break;
	default:
		p[index] = new PizzaWogy(1000 * Math.random(), "Pizzawogy", 1000 * Math.random());
		break;
	}}
	Arrays.sort(p);
	for(int index = 0;index<p.length;index++) {
		System.out.println(p[index]);
		System.out.println(" ");
	}
	
}
	}


