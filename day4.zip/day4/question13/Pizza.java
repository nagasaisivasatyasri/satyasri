package com.question13;
import java.lang.Comparable;
public class Pizza implements Comparable{
private double price;
private String name;
private double calories;
public Pizza(double price, String name, double calories) {
	super();
	this.price = price;
	this.name = name;
	this.calories = calories;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getCalories() {
	return calories;
}
public void setCalories(double calories) {
	this.calories = calories;
}
@Override
public int compareTo(Object o) {
	// TODO Auto-generated method stub
	Pizza p=(Pizza)o;
	if(this.price>p.price) {
		return 1;
	}
	else if(this.price<p.price) {
		return -1;
	}
	else {
		return 0;
	}
}
@Override
public String toString() {
	return "Pizza [price=" + price + ", name=" + name + ", calories=" + calories + "]";
}


}
