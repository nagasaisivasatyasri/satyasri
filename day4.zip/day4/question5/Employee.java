package com.question5;
public abstract class Employee {
	 String name;
     double age;
     double hourRate;
    
     public Employee(String name2, double age2, double hourRate2) {
		name=name2;
		age=age2;
		hourRate=hourRate2;
	}
	public abstract double salary(double hours);
     public String toString()
     {
              return  "name= "+ name + " age= " + age + "hourRate=" + hourRate;
     }

}
