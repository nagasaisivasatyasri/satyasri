package com.question5;

public class Clerk extends Employee{
	String name;
	 double age;
	 double hourRate;
	public Clerk(String name, double age, double hourRate) {
		super(name,age,hourRate);
		this.name = name;
		this.age = age;
		this.hourRate = hourRate;
	}
	@Override
	public double salary(double hours) {
		// TODO Auto-generated method stub
		return hours*hourRate;

}
	@Override
	public String toString() {
		return "Clerk [name=" + name + ", age=" + age + ", hourRate=" + hourRate + "]";
	}
	
}
