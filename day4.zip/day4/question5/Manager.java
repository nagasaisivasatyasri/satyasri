package com.question5;

public class Manager extends Employee {
 String name;
 double age;
 double hourRate;
public Manager(String name, double age, double hourRate) {
	super(name,age,hourRate);
	this.name = name;
	this.age = age;
	this.hourRate = hourRate;
}
public double salary(double hours) {
	// TODO Auto-generated method stub
	return hours*hourRate;
}
@Override
public String toString() {
	return "Manager [name=" + name + ", age=" + age + ", hourRate=" + hourRate + "]";
}


 }
