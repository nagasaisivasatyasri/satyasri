package com.question10;
import java.lang.Comparable;
public class Food implements Comparable{

	  private long calories;
      Food(long cal)
      {
               calories = cal;
      }
      
      public Food() {
		// TODO Auto-generated constructor stub
	}

	public void setCalories(long calories) {
		this.calories = calories;
	}

	long getCalories()
      {
               //add the missing code
    	  return calories;

      }
   
      public String toString()
      {
               return "calories="+calories;
      }
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		Food f=(Food)o;
		if(this.calories>f.calories)
		{ return 1; }
		else if(this.calories<f.calories)
		{ return -1; }
		else {
		return 0;}
	}

}
