package com.question10;

public class Flafel extends Food{
private long calories;
Flafel(double d) {
	super((long) d);
	calories=(long) d;

	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	System.out.println(super.toString());
	return "Flafel [calories=" + calories + "]";
}


}
