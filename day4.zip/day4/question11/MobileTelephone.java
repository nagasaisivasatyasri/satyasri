package com.question11;
import java.lang.Comparable;
public class MobileTelephone implements Comparable {

	 private double price;
	 
     public MobileTelephone(double price) {
		//super();
		this.price = price;
	}
	double getPrice()
     {
		return price;
              //add the missing code

     }
   
     public String toString()
     {
              //add the missing code
    	 return "Price= "+price;

     }
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		    	 MobileTelephone m=(MobileTelephone)o;
		    	 if(this.price>m.price) {
		    		 return 1;
		    	 }
		    	 else if(this.price<m.price) {
		    		 return -1;
		    	 }
		    	 else {
				return 0;
		    	 }//add the missing code


		             
		     }

}
