package com.question11;

import java.util.Arrays;

public class MobileTelephoneDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MobileTelephone vec[] = new MobileTelephone[50];
        for(int index=0; index<vec.length; index++)
        {
                  switch((int)(4*Math.random()))
                  {
                  case 1:vec[index]=new MotorolaMobilePhone(100*Math.random());
                  		break;
                  case 2:vec[index]=new NokiaMobilePhone(100*Math.random());
                  		break;
                  	default:vec[index]=new PanasonicMobilePhone(100*Math.random());
                  			break;
                  }

        }

        Arrays.sort(vec);

        for(int index=0; index<vec.length; index++)
        {
                  System.out.println(vec[index]);
                  System.out.println(" ");
        }

	}

}
