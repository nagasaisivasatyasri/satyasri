package com.question11;

public class MotorolaMobilePhone extends MobileTelephone {
	private double price;
public MotorolaMobilePhone(double price) {
		super(price);
		this.price=price;
		// TODO Auto-generated constructor stub
	}
@Override
public String toString() {
	System.out.println(super.toString());
	return "MotorolaMobilePhone [price=" + price + "]";
}


}
