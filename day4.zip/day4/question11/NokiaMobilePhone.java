package com.question11;

public class NokiaMobilePhone extends MobileTelephone{
private double price;
	public NokiaMobilePhone(double price) {
		super(price);
		this.price=price;
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		System.out.println(super.toString());
		return "NokiaMobilePhone [price=" + price + "]";
	}

}
