package com.question17;

public class Monitor {
String name="Aoc";
String model="TouchPad";
public void display()
{
	int width=15;
	int  length=56;
	System.out.println("Monitor is of "+length+" in length and  "+width+" in width");
}

@Override
public String toString() {
	return "Monitor [name=" + name + ", model=" + model + "]";
}
public Monitor() {
	//super();
}

}
