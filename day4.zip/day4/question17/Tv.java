package com.question17;

public class Tv extends Monitor{
String name="LG";
String model="smartTv";
int length=67;
int width=104;
public void display()
{
	super.display();
	System.out.println("Tv is of "+length+" in length and  "+width+" in width");
}
//@Override
public String toString() {
	Monitor m=new Monitor();
	System.out.println(m);
	return "Tv [name=" + name + ", model=" + model + ", length=" + length + ", width=" + width + "]";
}

}
