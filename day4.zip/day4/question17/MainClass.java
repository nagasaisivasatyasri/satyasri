package com.question17;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Tv t=new Tv();
System.out.println(t);
t.display();
	}

}
