package com.question14;

public class FootBall extends Game{

	public void play() {
		super.play();
		System.out.println("Let play  FootBall");
	}
	@Override
	public String toString() {
		System.out.println(super.toString());
		return "FootBall,Lets begin";
	}

}
