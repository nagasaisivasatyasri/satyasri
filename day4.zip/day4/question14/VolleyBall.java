package com.question14;

public class VolleyBall extends Game{
	public void play() {
		super.play();
		System.out.println("Let play  volleyball");
	}
	@Override
	public String toString() {
		System.out.println(super.toString());
		return "VolleyBall, Lets begin";
	}

}
