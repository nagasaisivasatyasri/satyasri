package com.question14;

public class BasketBall extends Game {
	public void play() {
		super.play();
		System.out.println("Let play  basketball");
	}
	

	@Override
	public String toString() {
		System.out.println(super.toString());
		return "Basketball, Lets begin";
	}
	

}
