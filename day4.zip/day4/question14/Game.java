package com.question14;

public class Game {
	public void play() {
		System.out.println("Let play a game");
	}
@Override
public String toString() {
	return "ohh! lets begin the game";
}

}
