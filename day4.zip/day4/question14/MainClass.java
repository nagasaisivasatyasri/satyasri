package com.question14;

import java.util.function.Consumer;
import java.util.function.Function;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Game v[]= {new BasketBall(),new VolleyBall(),new FootBall()};
for(int i=0;i<v.length;i++)
{
	v[i].play();
	System.out.println(v[i]);
	
	System.out.println(" ");
}



	}

}
