package com.assignments;

//import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSetEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashSet hset=new LinkedHashSet();
		hset.add(new ECommerceWebsite("Myntra","myntra"));
		hset.add(new ECommerceWebsite("LimeRoad","limeroad"));
		hset.add(new ECommerceWebsite("BigBazar","BigBazar"));
		hset.add(new ECommerceWebsite("snapdeal","snapdeal"));
		hset.add(null);
		System.out.println(hset);
		System.out.println(hset.isEmpty());
		System.out.println(hset.size());
		System.out.println(hset.stream());
		Iterator i=hset.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
			
		}
		hset.removeAll(hset);
		System.out.println(hset);

	}

}
