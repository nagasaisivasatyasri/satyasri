package com.assignments;

public class ECommerceWebsite {
private String c_name;
private String website_name;
@Override
public String toString() {
	return "ECommerceWebsite [c_name=" + c_name + ", website_name=" + website_name + "]";
}
//@Override

@Override
public boolean equals(Object obj) {
	// TODO Auto-generated method stub
	String s=(String)obj;
	boolean result=this.c_name==c_name && this.website_name==website_name;
	
	return  result;
}
@Override
public int hashCode() {
	// TODO Auto-generated method stub
	return super.hashCode();
}

public ECommerceWebsite(String c_name, String website_name) {
	super();
	this.c_name = c_name;
	this.website_name = website_name;
}
public String getC_name() {
	return c_name;
}
public void setC_name(String c_name) {
	this.c_name = c_name;
}
public String getWebsite_name() {
	return website_name;
}
public void setWebsite_name(String website_name) {
	this.website_name = website_name;
}


}
