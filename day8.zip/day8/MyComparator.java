package com.assignments;
import java.lang.Comparable;
import java.lang.String;
//import java.util.Comparator;
import java.util.Comparator;
public class MyComparator implements Comparator {

	
		@Override
		public int compare(Object o1, Object o2) {
			// TODO Auto-generated method stub
			String s=(String)o1;
			String s1=(String)o2;
			int x=s.compareToIgnoreCase(s1);
			if(x<0)
			{
				return 1;
			}
			else if(x>0)
			{
				return -1;
			}
			else
			{
				return 0;
			}
			
		}

	
}
