package com.assignments;

import java.util.Comparator;
import java.util.TreeSet;

public class TreesetEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
TreeSet ts=new TreeSet(new MyComparator());
ts.add("olx");
ts.add("quiker");
ts.add("snapdeal");
ts.add("amazon");
ts.add("ball");
System.out.println(ts);
System.out.println(ts.first());
System.out.println(ts.pollFirst());
System.out.println(ts.ceiling("Olx"));
System.out.println(ts.higher("Olx"));
System.out.println(ts.floor("amazon"));
System.out.println(ts.isEmpty());
System.out.println(ts.last());
System.out.println(ts.pollLast());
System.out.println(ts.size());
System.out.println(ts);
System.out.println(ts.tailSet("Olx"));
System.out.println(ts.headSet("Olx"));
System.out.println(ts.subSet("quicker","ball"));


	}

}
