package com.assignments;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Stack;

public class StackEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack stack=new Stack();
		System.out.println(stack.capacity());
		stack.addElement(new Patient(23,"sai","HeartHole"));
		stack.addElement(new Patient(25,"satya","Hairfall"));
		stack.push(new Patient(56,"devi","xxx"));
		stack.push(new Patient(12,"durga","YYY"));
		System.out.println(stack.pop());
		System.out.println(stack.peek());
		System.out.println(stack);
		System.out.println(stack.capacity());
		Iterator it = stack.iterator();
		ListIterator li = stack.listIterator();
		Enumeration e = stack.elements();
		System.out.println("Using iterators");
		while(it.hasNext())
		{
			Patient s2=(Patient)it.next();
			System.out.println(s2);

		}
		System.out.println();
		System.out.println("using Listiterators");
		while(li.hasNext())
		{
			System.out.println(li.next());
		}
		System.out.println();
		System.out.println("using enumaration ");
		while(e.hasMoreElements())
		{
			Patient s1=(Patient)e.nextElement();
		System.out.println(s1);
			
		}

	}

}
