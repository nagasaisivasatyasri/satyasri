package com.assignments;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
HashSet hset=new HashSet(4);
hset.add(new ECommerceWebsite("Amazon","amazon"));
hset.add(new ECommerceWebsite("FlipKart","flipkart"));
hset.add(new ECommerceWebsite("Reliance","digital"));
hset.add(new ECommerceWebsite("Reliance","ajio"));
hset.add(null);
System.out.println(hset);
System.out.println(hset.isEmpty());
System.out.println(hset.size());
System.out.println(hset.stream());
//System.out.println(hset.capacity());
Iterator i=hset.iterator();
while(i.hasNext()) {
	System.out.println(i.next());
	
}
hset.removeAll(hset);
System.out.println(hset);

}

}
