package com.assignments;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

import com.list.Student;

public class VectorEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector v = new Vector();
		System.out.println(v.capacity());
		v.addElement(new Patient(23,"sai","HeartHole"));
		v.addElement(new Patient(25,"satya","Hairfall"));
		System.out.println(v);
		System.out.println(v.capacity());
		System.out.println(v.firstElement());
		System.out.println(v.get(0));
		
		System.out.println(v.subList(0, 0));
		System.out.println(v.isEmpty());
		System.out.println(v.lastElement());
		System.out.println(v.elementAt(1));
		System.out.println(v.size());
		System.out.println(v.remove(0));
		Iterator it = v.iterator();
		ListIterator li = v.listIterator();
		Enumeration e = v.elements();
		System.out.println("Using iterators");
		while(it.hasNext())
		{
			Patient s2=(Patient)it.next();
			System.out.println(s2);

		}
		System.out.println();
		System.out.println("using Listiterators");
		while(li.hasNext())
		{
			System.out.println(li.next());
		}
		System.out.println();
		System.out.println("using enumaration ");
		while(e.hasMoreElements())
		{
			Patient s1=(Patient)e.nextElement();
		System.out.println(s1);
			
		}
		System.out.println(li.getClass().getName());

	
	}

}
