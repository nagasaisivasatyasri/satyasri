package com.assignments;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class ArrayListEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList a_list=new ArrayList();
a_list.add(new Patient(12,"dhawan","diabatis"));
a_list.add(new Patient(11,"Yuv raj","cancer"));
a_list.add(new Patient(13,"sonali","cancer"));
System.out.println(a_list);
System.out.println(a_list.size());
ArrayList a=new ArrayList();
a.add(new Patient(14,"gourav","bloodPressure"));
a.add(new Patient(17,"raj","cancer"));
System.out.println(a_list.contains(a));
a_list.addAll(a);
System.out.println(a_list);
System.out.println(a_list.containsAll(a));
System.out.println(a_list.remove(4));
System.out.println(a_list.indexOf(new Patient(13,"sonali","cancer")));
Iterator i=a_list.iterator();
while(i.hasNext())
{
	System.out.println(i.next());
}
System.out.println();
System.out.println("Using List iterator");
ListIterator li=a_list.listIterator();
while(li.hasNext())
{
	System.out.println(li.next());
}
	}

}
