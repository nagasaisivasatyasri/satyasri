package com.assignments;

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.HashSet;
import com.list.Student;

public class LinkedListEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList list=new LinkedList();
		//System.out.println(list.capacity());
		list.add(new Patient(23,"satya","Anemia"));
		list.add(new Patient(24,"rama","Thyroid"));
		Patient p1=new Patient(25,"satyasri","retinaProblem");
		Patient s1=p1;
		list.add(p1);
		list.add(s1);
		HashSet hset=new HashSet();
		hset.add(10);
		hset.add(12);
		hset.add(15);
		LinkedList li=new LinkedList(hset);
		//list.addAll(li);
		System.out.println(list);
		//sysoutlist.removeLastOccurrence();
		System.out.println(list);
		System.out.println(list.pollFirst());
		System.out.println(list.pollLast());
		System.out.println(list.isEmpty());
		System.out.println(list.getFirst());
		System.out.println(list.getLast());
		System.out.println(list.peekFirst());
		System.out.println(list.peekLast());
		System.out.println(list);
		
		ListIterator l1=list.listIterator();
		while(l1.hasNext())
		{
			Patient s2=(Patient)l1.next();
			
			System.out.println(s2);
			
		}

	}

}
