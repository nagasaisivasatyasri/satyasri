package com.assignments.question1;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Iterator;
//import java.util.LinkedList;
//import java.util.ListIterator;

public class ByteArrayIOEx {

	public static void main(String []args) throws IOException {
		// TODO Auto-generated method stub
	FileOutputStream fis=new FileOutputStream("data.txt");
	//FileOutputStream f1=new FileOutputStream("object.txt");
	FileOutputStream f2=new FileOutputStream("same.txt");
	ByteArrayOutputStream b2=new ByteArrayOutputStream();
	//ByteArrayOutputStream b3=new ByteArrayOutputStream();
	ByteArrayOutputStream b4=new ByteArrayOutputStream();
	//b1(new Student(34,"satya","kkh"));
	b2.write(14);
	b2.write(45);
	b2.write(56);
	b2.writeTo(fis);
	String str="Java is too easy";
	byte by[]=str.getBytes();
	b4.writeTo(f2);
	b4.close();
	b2.close();
	f2.close();
	fis.close();
	System.out.println("data entered");
	byte ad[]= {34,56,76};
	ByteArrayInputStream byt=new ByteArrayInputStream(ad);
	int n=0;
	while((n=byt.read())!=-1) {
		System.out.print((char)n);}
		}}

