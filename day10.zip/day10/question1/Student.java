package com.assignments.question1;

import java.io.Serializable;

//import day10.Student;

public class Student implements Serializable {
	private int id;
	private String studentname;
	private String city;
	public Student(int id, String studentname, String city) {
		super();
		this.id = id;
		this.studentname = studentname;
		this.city = city;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return id;
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		Student s=(Student)obj;
		
		return this.id==s.id;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", studentname=" + studentname + ", city=" + city + "]";
	}


}
