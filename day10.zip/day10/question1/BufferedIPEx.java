package com.assignments.question1;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class BufferedIPEx {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileOutputStream fout = new FileOutputStream("data.txt"); 
        
        //creating bufferdOutputStream obj 
        BufferedOutputStream bout = new BufferedOutputStream(fout); 
  
        //illustrating write() method 
        for(int i = 65; i < 75; i++) 
        { 
            bout.write(i); 
        }  
        byte b[] = { 75, 76, 77, 78, 79, 80 }; 
        bout.write(b);      
        
          
        //illustrating close() method 
        bout.close(); 
        fout.close(); 
        FileInputStream fo2=new FileInputStream("data.txt");
		BufferedInputStream o=new BufferedInputStream(fo2);
		int n=0;
		while((n=o.read())!=-1)
		{
			System.out.print((char)n);
		}
        
	}

}
