package com.assignments.question1;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataIOEx {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
FileOutputStream fos=new FileOutputStream("data.txt");
FileOutputStream f2=new FileOutputStream("same.txt");
//FileOutputStream f1=new FileOutputStream("object.txt");
DataOutputStream dos=new DataOutputStream(fos);
DataOutputStream dos1=new DataOutputStream(f2);
//DataOutputStream dos2=new DataOutputStream(fo);
dos.writeInt(15000);
dos.writeDouble(45.56d);
dos1.writeBytes("This is data Io stream");
dos.close();
dos1.close();
f2.close();
fos.close();
FileInputStream fis=new FileInputStream("data.txt");
DataInputStream dis=new DataInputStream(fis);
System.out.println(dis.readInt()+" "+dis.readDouble());
FileInputStream fis1=new FileInputStream("same.txt");
DataInputStream dis1=new DataInputStream(fis1);
int n=0;
while((n=dis1.read())!=-1)
{
	System.out.print((char)n);
}

	}

}