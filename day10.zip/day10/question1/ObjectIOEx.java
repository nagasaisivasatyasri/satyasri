package com.assignments.question1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectIOEx {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		FileOutputStream fis=new FileOutputStream("data.txt");
		FileOutputStream f2=new FileOutputStream("same.txt");
		FileOutputStream f1=new FileOutputStream("object.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fis);
		ObjectOutputStream oos2=new ObjectOutputStream(f2);
		ObjectOutputStream oos1=new ObjectOutputStream(f1);
		oos.writeInt(45);
		oos.writeDouble(52.36d);
		oos1.writeObject(new Student(12,"satya","vsp"));
		//oos2.writeChars("I am very happy");
		oos2.writeBytes("i am not happy");
		oos.close();
		oos1.close();
		oos2.close();
		f1.close();
		f2.close();
		fis.close();
		FileInputStream fo=new FileInputStream("data.txt");
		ObjectInputStream obj=new ObjectInputStream(fo);
		System.out.println(obj.readInt()+"  "+obj.readDouble());
		FileInputStream fo1=new FileInputStream("object.txt");
		ObjectInputStream ob=new ObjectInputStream(fo1);
		System.out.println(ob.readObject());
		FileInputStream fo2=new FileInputStream("same.txt");
		ObjectInputStream o=new ObjectInputStream(fo2);
		int n=0;
		while((n=o.read())!=-1)
		{
			System.out.print((char)n);
		}
		//System.out.println(o.readByte());
		
	}

}
