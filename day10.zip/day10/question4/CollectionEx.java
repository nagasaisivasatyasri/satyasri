package com.assignment.question4;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CollectionEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList al = new ArrayList();
		
		al.add(101);
		al.add(105);
		al.add(51);
		al.add(501);
		al.add(1);	

		System.out.println(al);
		System.out.println(Collections.min(al));
		Collections.reverse(al);
		System.out.println(al);
		System.out.println(Collections.max(al));
		
		 List<Integer> list = Arrays.asList(3,2,1,4,5,6,6);

	        for (Integer integer : list) {
	            System.out.println(integer);
	        }
	        for (int i = 0; i < al.size(); i++) 
	            System.out.print(al.get(i) + " "); 

	        System.out.println(al.hashCode());
	        System.out.println(al.isEmpty());
	        
	     	    }

	}


