package com.assignment.question5;

import java.util.ArrayList;
import java.util.LinkedList;

interface Shape{
	void draw();
	
}
class Circle implements Shape
{
	int radius;
	
	public Circle(int radius) {
		//super();
		this.radius = radius;
	}

	@Override
	public String toString() {
		return "Circle [radius=" + radius + "]";
	}

	public void draw()
	{
		System.out.println("Draw a Circle");
	}
}
class Rectangle implements Shape
{
	int length,width;
	
	public Rectangle(int length, int width) {
		//super();
		this.length = length;
		this.width = width;
	}

	@Override
	public String toString() {
		return "Rectangle [length=" + length + ", width=" + width + "]";
	}

	public void draw()
	{
		System.out.println("Draw a Rectangle");
	}
}
class Square implements Shape
{
	int side;
	
	public Square(int side) {
	//	super();
		this.side = side;
	}

	@Override
	public String toString() {
		return "Square [side=" + side + "]";
	}

	public void draw()
	{
		System.out.println("Draw a Square");
	}
}

public class ShapeEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Shape> l=new LinkedList();
		
		Shape s=new Circle(12);
		l.add(s);
		s=new Rectangle(23,34);
		l.add(s);
		s=new Square(56);
		l.add(s);
		ShapeEx s1=new ShapeEx();
		s1.call(l);
				
				
			
								
			}

	private void call(LinkedList<? extends Shape> al) {
		// TODO Auto-generated method stub
		for(Shape s:al)
		{
			System.out.println(s);
	}
			

			
			}

	}


