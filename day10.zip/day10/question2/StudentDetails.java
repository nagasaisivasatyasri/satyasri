package com.assignment.question2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

public class StudentDetails {

	public static void main(String[] args) throws IOException, ClassNotFoundException ,ClassCastException {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter name to create a file");
String name=s.next();
s.nextLine();
FileOutputStream f=new FileOutputStream(".txt");
ObjectOutputStream oos=new ObjectOutputStream(f);
Student s1=new Student();
System.out.println("File created with student name");
System.out.println("Enter student id");
s1.setId(s.nextInt());
System.out.println("Enter student full name");
s1.setStudentname(s.next());
s.nextLine();
System.out.println("Enter student father name");
s1.setFathername(s.next());
System.out.println("enter date of birth");
s1.setDob(s.next());
System.out.println("Enter marks");
s1.setM(s.nextInt());
s1.setP(s.nextInt());
s1.setC(s.nextInt());
oos.writeObject(s1);
double total=s1.total();
System.out.println(total);
double avg=s1.avg();
System.out.println(avg);

//s1.avg();
String str=s1.rank();
System.out.println(str);

oos.writeObject(s1);
oos.close();
f.close();
System.out.println("object wriiten in to file");

	}

}
