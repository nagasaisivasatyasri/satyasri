package com.assignment.question2;

import java.io.Serializable;

public class Student implements Serializable {
private int id;
private String studentname;
private String fathername;
private String dob;
private double total;
private double avg;
private int m,p,c;
private String rank;

public Student() {
	//super();
}
public Student(int id, String studentname, String fathername, String dob, int m, int p, int c) {
	//super();
	this.id = id;
	this.studentname = studentname;
	this.fathername = fathername;
	this.dob = dob;
	this.m = m;
	this.p = p;
	this.c = c;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getStudentname() {
	return studentname;
}
public void setStudentname(String studentname) {
	this.studentname = studentname;
}
public String getFathername() {
	return fathername;
}
public void setFathername(String fathername) {
	this.fathername = fathername;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public int getM() {
	return m;
}
public void setM(int m) {
	this.m = m;
}
public int getP() {
	return p;
}
public void setP(int p) {
	this.p = p;
}
public int getC() {
	return c;
}
public void setC(int c) {
	this.c = c;
}
public double total() {
	
return this.p+this.m+this.c;
}
public double avg() {
	
	return total()/3;
}
public String rank() {
	if(avg()>=75 && avg()<100) {return "A";}
	else if(avg()>=50 && avg()<75) {return "B";}
	else {return "C";}}
@Override
public String toString() {
	return "Student [id=" + id + ", studentname=" + studentname + ", fathername=" + fathername + ", dob=" + dob
			+ ", total=" + total() + ", avg=" + avg() + ", m=" + m + ", p=" + p + ", c=" + c + ", rank=" + rank() + "]";
}

}

