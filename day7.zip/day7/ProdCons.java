//package com.assignments;

import java.util.LinkedList;

public class ProdCons {

	public static void main(String[] args) throws InterruptedException  {
		// TODO Auto-generated method stub
final ProducerConsumer p=new ProducerConsumer();

Thread t=new Thread(new  Runnable() {
	public void run()
	{
		try {
			//Thread.sleep(1000);
			p.produce();
		} 
		catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			}
});
Thread t1=new Thread(new Runnable() {
	public void run()
	{
		try {
			p.consume();
			//Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
});
t1.start();
t.start();
	t1.join();
t.join();


	}

}
class ProducerConsumer
{LinkedList<Integer> list=new LinkedList<>();
final static int capacity=2;
int c=0;
void produce() throws InterruptedException
{
	int value=0;
	//int c=0;
	while(true) {
synchronized(this) {

		while(list.size()==capacity) 
				wait();
			System.out.println("Producer produced "+value);
			list.add(value++);
			notify();
			Thread.sleep(1000);
			}
		}
	
}
void consume() throws InterruptedException 
{
	int value=0;
	while(true) {
	synchronized(this){
		while(list.size()==0) 
		//p.produce())
			
			wait();
			int val=list.removeFirst();
			System.out.println("Consumer consumed "+val);
			notify();
			Thread.sleep(1000);
					}
	}
}
 


	
}
