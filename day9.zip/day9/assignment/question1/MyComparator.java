package com.assignment.question1;
import java.util.Comparator;
public class MyComparator implements Comparator  {

	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		Student s2=(Student)o1;
		Student s3=(Student)o2;
		int res=s2.compareTo(s3);
		double c=s2.average();
		int d=(int)c;
		double c1=s3.average();
		int d1=(int)c1;
		//double d1=s3.average();
		if(d>75 || d1>75) {
			return 1;
		}
		else if(d>0 && d1>0)
			{
				return -1;
			}
			
		else {
			return 0;
		}
		
		//return result;
	}

	}
