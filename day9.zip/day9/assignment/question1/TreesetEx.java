package com.assignment.question1;

import java.util.Iterator;
import java.util.TreeSet;

public class TreesetEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet t1=new TreeSet();
TreeSet t=new TreeSet(new MyComparator());

Student st1=new Student("rohit",13,98,99,99);
Student st2=new Student("charan",14,34,34,34);
Student st3=new Student("tej",15,56,78,12);
t.add(st1);
t.add(st2);
t.add(st3);

t1.add(st1);
t1.add(st2);
t1.add(st3);
//System.out.println(t1);

Iterator i1=t1.iterator();
while(i1.hasNext()) {
	Student s2=(Student)i1.next();
	System.out.println(s2);
}
System.out.println();
Iterator i=t.iterator();
while(i.hasNext()) {
	Student s1=(Student)i.next();
	System.out.println(s1);
}
	}

}
