package com.assignment.question2;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashTableEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Hashtable h=new Hashtable();
h.put(new Customer(12,"satya","plk"),"washing machine");
h.put(new Customer(13,"sai","vsp"),"Tv");
h.put(new Customer(12,"Mahi","Klp"),"AC");
h.put(new Customer(14,"mahima","Up"),"Laptop");
System.out.println(h);
Set s=h.entrySet();
Iterator i=s.iterator();
while(i.hasNext())
{
	Map.Entry map=(Entry) i.next();
	System.out.println(map.getKey()+" "+map.getValue());
}
	}

}
