package com.assignment.question2;

public class Customer {
private int id;
private String customername;
private String customeraddress;
@Override
public String toString() {
	return "Customer [id=" + id + ", customername=" + customername + ", customeraddress=" + customeraddress + "]";
}
public Customer(int id, String customername, String customeraddress) {
	//super();
	this.id = id;
	this.customername = customername;
	this.customeraddress = customeraddress;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getCustomername() {
	return customername;
}
public void setCustomername(String customername) {
	this.customername = customername;
}
public String getCustomeraddress() {
	return customeraddress;
}
public void setCustomeraddress(String customeraddress) {
	this.customeraddress = customeraddress;
}
@Override
public int hashCode() {
	// TODO Auto-generated method stub
	return id;
}
@Override
public boolean equals(Object obj) {
	// TODO Auto-generated method stub
	Customer c=(Customer)obj;
	return this.id==c.id;
}


}
