package com.assignment.question5;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;


public class TreeMapEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap t=new TreeMap();
		Employee e1=new Employee(12,"Satya","Pkl");
		Student s1=new Student(13,"sai");
		Employee e2=new Employee(45,"rohan","Usa");
		Student s2=new Student(17,"sharath");
		Employee e3=new Employee(56,"pavan","KLU");
		Student s3=new Student(23,"hari");
		//Employee e4=new Employee(56,"pavan","KLU",12000);
		t.put(e1,s1);
		t.put(e2, s2);
		t.put(e3, s3);
		TreeMap tm1=new TreeMap();
		Employee e4=new Employee(34,"shail","kkd");
		Student s4=new Student(367,"shail");
		tm1.put(e4,s4);
		t.putAll(tm1);
		System.out.println(t.descendingMap());
		
		System.out.println(t.firstKey());
		
		System.out.println(t.containsValue("Shaul"));
		
		System.out.println(t.containsKey(new Employee(56,"pavan","KLU")));
		
		System.out.println(t.pollFirstEntry());
		System.out.println(t.get(new Employee(56,"pavan","KLU")));
		
		System.out.println(t.replace(new Employee(34,"shail","kkd"),new Student(456,"dhanush")));
		System.out.println(t);
		System.out.println(t.tailMap(new Employee(56,"pavan","KLU")));
		
		System.out.println(t.headMap(new Employee(56,"pavan","KLU")));
		
		System.out.println(t.values());
		
		System.out.println(t.subMap(e1,e4));
		
		//System.out.println(tm.subMap(2, false, 5, true));
		
		System.out.println(t);
		
		
	
		System.out.println(t.size());
		System.out.println(t);
		Set set=t.entrySet();
		Iterator i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry ent= (Entry) i.next();
			System.out.println(ent.getKey()+" "+ent.getValue());
		}

	}

}
