package com.assignment.question5;
import java.lang.Comparable;

//import com.assignment.question4.Employee;
public class Employee implements Comparable {
private int employeeid;
private String employeeName;
private String city;
public Employee(int employeeid, String employeeName, String city) {
	//super();
	this.employeeid = employeeid;
	this.employeeName = employeeName;
	this.city = city;
}

public int getEmployeeid() {
	return employeeid;
}

public void setEmployeeid(int employeeid) {
	this.employeeid = employeeid;
}

public String getEmployeeName() {
	return employeeName;
}

public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

@Override
public String toString() {
	return "Employee [employeeid=" + employeeid + ", employeeName=" + employeeName + ", city=" + city + "]";
}
@Override
public int hashCode() {
	// TODO Auto-generated method stub
	return employeeid;
}
@Override
public boolean equals(Object obj) {
	// TODO Auto-generated method stub
	Employee e=(Employee)obj;
	return this.employeeid==e.employeeid;
}

@Override
public int compareTo(Object o) {
	// TODO Auto-generated method stub
	Employee e=(Employee)o;

	if(this.employeeid>e.employeeid)
	{
		return 1;
	}
	else if(this.employeeid<e.employeeid)
	{
		return -1;
	}
	else {
	return 0;
	}

	}

}
