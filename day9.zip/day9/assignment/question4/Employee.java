package com.assignment.question4;
import java.lang.Comparable;
public class Employee implements Comparable {
private int id;
private String customername;
private String customeradd;
private int salary;
public Employee(int id, String customername, String customeradd,int salary) {
	//super();
	this.id = id;
	this.customername = customername;
	this.customeradd = customeradd;
	this.salary=salary;
}

public Employee(int i, String string, String string2) {
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return "Employee [id=" + id + ", customername=" + customername + ", customeradd=" + customeradd + ", salary="
			+ salary + "]";
}

@Override
public int hashCode() {
	// TODO Auto-generated method stub
	return id;
}
@Override
public boolean equals(Object obj) {
	// TODO Auto-generated method stub
	Employee c=(Employee)obj;
	return this.id==c.id;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getCustomername() {
	return customername;
}
public void setCustomername(String customername) {
	this.customername = customername;
}
public String getCustomeradd() {
	return customeradd;
}
public void setCustomeradd(String customeradd) {
	this.customeradd = customeradd;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
@Override
public int compareTo(Object o) {
	// TODO Auto-generated method stub
	Employee e=(Employee)o;

	if(this.salary>e.salary)
	{
		return 1;
	}
	else if(this.salary<e.salary)
	{
		return -1;
	}
	else {
	return 0;
	}
	}


}
