package com.assignment.question4;

import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

//import org.graalvm.compiler.core.common.alloc.TraceMap;

public class TreeMapsEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
TreeMap t=new TreeMap(new Comparator() {

	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		Employee emp=(Employee)o1;
		Employee emp1=(Employee)o2;
		if(emp1.getSalary()>emp.getSalary())
		{
			return 1;
		}
		else if(emp1.getSalary()<emp.getSalary())
		{
			return -1;
		}
		else {
		return 0;
	}
	}}) ;
	
Employee e1=new Employee(12,"Satya","Pkl",90000);
Student s1=new Student(13,"sai","pkl");
Employee e2=new Employee(45,"rohan","Usa",10000);
Student s2=new Student(17,"sharath","UK");
Employee e3=new Employee(56,"pavan","KLU",12000);
Student s3=new Student(23,"hari","pk");
//Employee e4=new Employee(56,"pavan","KLU",12000);
t.put(e1,s1);
t.put(e2, s2);
t.put(e3, s3);
System.out.println(t);
Set set=t.entrySet();
Iterator i=set.iterator();
while(i.hasNext())
{
	Map.Entry ent= (Entry) i.next();
	System.out.println(ent.getKey()+" "+ent.getValue());
}


	}

}
