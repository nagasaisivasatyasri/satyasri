package com.assignment.question3;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Properties;

public class PropertiesIoEx {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileReader file=new FileReader("someproperties");
		//InputStream is=new InputStream("someproperties");
		Properties p=new Properties();
		p.load(file);//load(Reader r)
		//p.load(InputStream("someproperties"));
		p.setProperty("rupa","scet");
		System.out.println(p.size());
		p.store(new FileWriter("someproperties"),"Java is very easy if you concentrate");
		//p.save(new OutputStream("someproperties"),"you can win");
		System.out.println(p.getProperty("satya"));
		System.out.println(p.isEmpty());
		//System.out.println(p.contains("satya"));
		System.out.println(p.getProperty("satya","BVc"));
		PrintWriter writer = new PrintWriter(System.out); 
		 // print the list with a PrintWriter object 
        p.list(writer); 
          // flush the stream and display 
       // System.out.println("listing out the Properties: "); 
        writer.flush(); 
        
    } 
} 
